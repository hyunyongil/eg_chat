import React from 'react';
import './error.css'

function Error(props) {
    return (
        <div className="error-load">
            <strong>접근권한이 없습니다.</strong>
        </div>
    );
}

export default Error;